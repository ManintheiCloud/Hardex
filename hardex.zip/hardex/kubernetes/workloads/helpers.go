// Package workloads implements checks on pod specifications: privilege,
// host access, Linux security modules, capabilities, and supply-chain hygiene.
//
// Together, the HX-WL rules cover every control in the Kubernetes Pod
// Security Standards (Baseline and Restricted levels), plus additional
// NSA/CISA recommendations that PSS does not include.
package workloads

import (
	"fmt"
	"strings"

	"github.com/hardex-project/hardex/core/assessment"
	"github.com/hardex-project/hardex/core/resource"
)

// containerVisitor is called for each container of each workload.
type containerVisitor func(ctx *assessment.Context, obj *resource.Object, pod map[string]any, prefix string, c resource.Container)

// eachContainer builds an ObjectRule that visits every container.
func eachContainer(meta assessment.Metadata, fn containerVisitor) assessment.Rule {
	return eachPod(meta, func(ctx *assessment.Context, obj *resource.Object, pod map[string]any, prefix string) {
		for _, c := range resource.Containers(pod) {
			fn(ctx, obj, pod, prefix, c)
		}
	})
}

// eachPod builds an ObjectRule that visits every workload's pod spec.
func eachPod(meta assessment.Metadata, fn func(ctx *assessment.Context, obj *resource.Object, pod map[string]any, prefix string)) assessment.Rule {
	return assessment.ObjectRule{
		Meta:  meta,
		Kinds: resource.WorkloadKinds(),
		Check: func(ctx *assessment.Context, obj *resource.Object) {
			pod, prefix := resource.PodSpec(obj)
			if pod == nil {
				return
			}
			if !ctx.Options.IncludeSystem && isControlPlaneStaticPod(obj) {
				// Assessed by the control-plane rules, which understand
				// that these components legitimately need host access.
				return
			}
			fn(ctx, obj, pod, prefix)
		},
	}
}

var controlPlaneComponents = map[string]bool{
	"kube-apiserver": true, "kube-controller-manager": true, "kube-scheduler": true, "etcd": true,
}

func isControlPlaneStaticPod(obj *resource.Object) bool {
	if obj.Kind != "Pod" || obj.EffectiveNamespace() != "kube-system" {
		return false
	}
	labels := resource.Map(obj.Raw, "metadata", "labels")
	comp, _ := labels["component"].(string)
	return controlPlaneComponents[comp]
}

// effective resolves a security context field that may be set at the pod
// level and overridden per container. It returns the value, the path it was
// read from, and whether it was set at all.
func effective(pod map[string]any, prefix string, c resource.Container, field ...string) (any, string, bool) {
	cPath := append([]string{"securityContext"}, field...)
	if v, ok := resource.Lookup(c.Spec, cPath...); ok {
		return v, c.Path(prefix) + "." + strings.Join(cPath, "."), true
	}
	if v, ok := resource.Lookup(pod, cPath...); ok {
		return v, prefix + "." + strings.Join(cPath, "."), true
	}
	return nil, c.Path(prefix) + "." + strings.Join(cPath, "."), false
}

// isWindows reports whether the pod declares a Windows OS. Several Linux-only
// controls do not apply to Windows pods (per the Pod Security Standards).
func isWindows(pod map[string]any) bool {
	return resource.String(pod, "os", "name") == "windows"
}

func show(v any) string {
	if v == nil {
		return "<unset>"
	}
	return fmt.Sprint(v)
}

func normalizeCap(c string) string {
	return strings.TrimPrefix(strings.ToUpper(strings.TrimSpace(c)), "CAP_")
}
