// Package kubernetes assembles the built-in Hardex rule set.
package kubernetes

import (
	"github.com/hardex-project/hardex/core/assessment"
	"github.com/hardex-project/hardex/kubernetes/controlplane"
	"github.com/hardex-project/hardex/kubernetes/networking"
	"github.com/hardex-project/hardex/kubernetes/nodes"
	"github.com/hardex-project/hardex/kubernetes/rbac"
	"github.com/hardex-project/hardex/kubernetes/secrets"
	"github.com/hardex-project/hardex/kubernetes/workloads"
)

// Registry returns a validated registry of every built-in rule.
func Registry() (*assessment.Registry, error) {
	var all []assessment.Rule
	for _, group := range [][]assessment.Rule{
		workloads.Rules(), secrets.Rules(), rbac.Rules(), networking.Rules(), controlplane.Rules(), nodes.Rules(),
	} {
		all = append(all, group...)
	}
	return assessment.NewRegistry(all...)
}
